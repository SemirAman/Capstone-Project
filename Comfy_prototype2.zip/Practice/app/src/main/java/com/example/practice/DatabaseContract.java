package com.example.practice;

import android.provider.BaseColumns;

public final class DatabaseContract {
    private DatabaseContract() {
    }

    public static class DatabaseEntity implements BaseColumns {
        public static final String TABLE_NAME = "users";
        public static final String COLUMN_NAME_USER_NAME = "user_name";
        public static final String COLUMN_NAME_USER_EMAIL = "user_email";
        public static final String COLUMN_NAME_USER_PASSWORD = "user_password";

    }

    public static final String SQL_CREATE_ITEMS = "CREATE TABLE "+
            DatabaseEntity.TABLE_NAME+" ( "+
            DatabaseEntity._ID+" INTEGER PRIMARY KEY, "+
            DatabaseEntity.COLUMN_NAME_USER_NAME+" TEXT, "+
            DatabaseEntity.COLUMN_NAME_USER_EMAIL+" TEXT, "+
            DatabaseEntity.COLUMN_NAME_USER_PASSWORD+" TEXT )";

    public static final String SQL_DROP_ITEMS = "DROP TABLE IF EXISTS " + DatabaseEntity.TABLE_NAME;
}
