package com.example.practice;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper2 extends SQLiteOpenHelper{
    public static final int DATABASE_VERSION = 2;
    private static final String DATABASE_USER_POST ="post.db";


    public DatabaseHelper2(Context context){
        super(context, DATABASE_USER_POST, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DatabaseContract2.SQL_CREATE_ITEMS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DatabaseContract2.SQL_DROP_ITEMS);
        onCreate(db);
    }

//    public long addUser(String user, String password){
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues contentValues = new ContentValues();
//        contentValues.put("username",user);
//        contentValues.put("password",password);
//        long res = db.insert("registeruser",null,contentValues);
//        db.close();
//        return  res;
//    }
//
//    public boolean checkUser(String username, String password){
//        String[] columns = { COL_1 };
//        SQLiteDatabase db = getReadableDatabase();
//        String selection = COL_2 + "=?" + " and " + COL_3 + "=?";
//        String[] selectionArgs = { username, password };
//        Cursor cursor = db.query(TABLE_NAME,columns,selection,selectionArgs,null,null,null);
//        //db.execSQL?
//        int count = cursor.getCount();
//        cursor.close();
//        db.close();
//
//        if(count>0)
//            return  true;
//        else
//            return  false;
//    }
}