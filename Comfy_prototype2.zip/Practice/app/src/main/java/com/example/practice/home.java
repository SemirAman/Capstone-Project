package com.example.practice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class home extends AppCompatActivity {

    DatabaseHelper2 dbHelper2 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        dbHelper2 = new DatabaseHelper2(this);
        Cursor c = getAllItems();
        final List list = new ArrayList<String>();
        while (c.moveToNext()){
            list.add(c.getString(1));
        }

        ListView listView = (ListView) findViewById(R.id.listPost);
        final ArrayAdapter<String> listViewAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, list);
        listView.setAdapter(listViewAdapter);
    }


    private Cursor getAllItems(){
        SQLiteDatabase db = dbHelper2.getReadableDatabase();
        String query = "SELECT * FROM "+ DatabaseContract2.DatabaseEntity.TABLE_NAME;
        Cursor cursor  = db.rawQuery(query, null);
        return cursor;
    }


    public void goBack(View view) {
        Intent intent = new Intent(this, login.class);

        startActivity(intent);
    }

    public void createPost(View view) {
        Intent NPost = new Intent(this, NewPost.class);

        startActivity(NPost);
    }
}
