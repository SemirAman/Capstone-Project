package com.example.practice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static com.example.practice.DatabaseContract.DatabaseEntity.TABLE_NAME;

public class login extends AppCompatActivity {
    EditText txtUser;
    EditText txtPass;
    Button btnLog;
    DatabaseHelper dbHelper = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        dbHelper = new DatabaseHelper(this);

        txtUser = findViewById(R.id.txtUser);
        txtPass = findViewById(R.id.txtPass);
        btnLog = findViewById(R.id.btnLog);

        btnLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = txtUser.getText().toString().trim();
                String pwd = txtPass.getText().toString().trim();
                boolean check = checkUser(user, pwd);
                if (check){
                    Toast.makeText(login.this,"you have logged in",Toast.LENGTH_SHORT).show();
                    Intent home = new Intent(login.this,home.class);
                    startActivity(home);
                }else{
                    Toast.makeText(login.this,"wrong username or password",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    public boolean checkUser(String email, String password) {

        String[] columns = {
                DatabaseContract.DatabaseEntity._ID
        };
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String selection = DatabaseContract.DatabaseEntity.COLUMN_NAME_USER_EMAIL + " = ?" + " AND " + DatabaseContract.DatabaseEntity.COLUMN_NAME_USER_PASSWORD + " = ?";
        String[] selectionArgs = {email, password};

        Cursor cursor = db.query(TABLE_NAME, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                       //filter by row groups
                null);                      //The sort order

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }

        return false;
    }


    public void signup(View view) {
        Intent signup = new Intent(this, SignUp.class);

        startActivity(signup);
    }


}
