package com.example.practice;

import android.provider.BaseColumns;

public final class DatabaseContract2 {
    private DatabaseContract2() {
    }

    public static class DatabaseEntity implements BaseColumns {
        public static final String TABLE_NAME = "post";
        public static final String COLUMN_USER_POST = "post_desc";
    }

    public static final String SQL_CREATE_ITEMS = "CREATE TABLE "+
            DatabaseEntity.TABLE_NAME+" ( "+
            DatabaseEntity._ID+" INTEGER PRIMARY KEY, "+
            DatabaseEntity.COLUMN_USER_POST+" TEXT)";

    public static final String SQL_DROP_ITEMS = "DROP TABLE IF EXISTS " + DatabaseEntity.TABLE_NAME;
}
