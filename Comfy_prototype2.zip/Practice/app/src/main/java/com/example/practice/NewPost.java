package com.example.practice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class NewPost extends AppCompatActivity {
    EditText txtPost;
    Button btnPost;
    DatabaseHelper2 dbHelper2 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newpost);
        dbHelper2 = new DatabaseHelper2(this);
        txtPost = findViewById(R.id.editPost);
        btnPost = findViewById(R.id.btnPublish);

        btnPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String desc = txtPost.getText().toString().trim();

                if(txtPost.length()!=0) {
                    addPost(desc);
                    Toast.makeText(NewPost.this, "You have registered", Toast.LENGTH_SHORT).show();
                    Intent moveToHome = new Intent(NewPost.this, home.class);
                    startActivity(moveToHome);
                }
                else{
                    Toast.makeText(NewPost.this,"missing info",Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    private void addPost(String desc) {
        SQLiteDatabase db = dbHelper2.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseContract2.DatabaseEntity.COLUMN_USER_POST, desc);

        // Inserting Row
        db.insert(DatabaseContract2.DatabaseEntity.TABLE_NAME, null, values);
        db.close();
    }

    public void cancelpost(View view) {
        Intent postCancel = new Intent(this, home.class);

        startActivity(postCancel);
    }
}
