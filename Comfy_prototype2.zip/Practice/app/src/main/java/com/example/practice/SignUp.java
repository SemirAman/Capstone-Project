package com.example.practice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignUp extends AppCompatActivity {
    DatabaseHelper dbHelper = null;
    EditText edit_Name;
    EditText edit_Pass;
    EditText edit_Email;
    Button btn_Register;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);

        dbHelper = new DatabaseHelper(this);
        edit_Name = findViewById(R.id.editName);
        edit_Pass = findViewById(R.id.editPass);
        edit_Email = findViewById(R.id.editEmail);
        btn_Register = findViewById(R.id.btnRegister);


        btn_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = edit_Name.getText().toString().trim();
                String pwd = edit_Pass.getText().toString().trim();
                String email = edit_Email.getText().toString().trim();

                if(email.length()!=0 && user.length()!=0 && pwd.length()!=0) {
                    addUser(user, email, pwd);
                    Toast.makeText(SignUp.this, "You have registered", Toast.LENGTH_SHORT).show();
                    Intent moveToHome = new Intent(SignUp.this, home.class);
                    startActivity(moveToHome);
                }
                    else{
                    Toast.makeText(SignUp.this,"missing info",Toast.LENGTH_SHORT).show();
                    }
            }
        });
    }

    public void addUser(String name, String user, String pass) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseContract.DatabaseEntity.COLUMN_NAME_USER_NAME, name);
        values.put(DatabaseContract.DatabaseEntity.COLUMN_NAME_USER_EMAIL, user);
        values.put(DatabaseContract.DatabaseEntity.COLUMN_NAME_USER_PASSWORD, pass);

        // Inserting Row
        db.insert(DatabaseContract.DatabaseEntity.TABLE_NAME, null, values);
        db.close();
    }

    public void cancel(View view) {
            Intent intent = new Intent(this, login.class);

            startActivity(intent);

    }
}
